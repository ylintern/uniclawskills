# 🦞 UniClaw - Uniswap LP Quant Framework

**Professional-grade AI skill for Uniswap V3/V4 liquidity provision with institutional risk analytics.**

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Claude Skill](https://img.shields.io/badge/Claude-Skill-8A2BE2)](https://claude.ai)
[![Uniswap V3](https://img.shields.io/badge/Uniswap-V3%2FV4-FF007A)](https://uniswap.org)

UniClaw transforms Claude into a quantitative analyst for DeFi liquidity provision, combining:
- 📊 Advanced risk analytics (VaR, Monte Carlo, volatility forecasting)
- 🎯 Precise fee accounting and IL calculation
- 🔬 Backtesting framework with performance metrics
- ⚡ V3 position management + V4 hooks development
- 🧮 Optimal range calculation and rebalancing strategies

**Built by [Orki Finance](https://github.com/your-org) | Released Open Source for the Community**

---

## 🚀 Quick Start

### Installation

1. **Copy the skill file:**
   ```bash
   # Download SKILL.md to your Claude desktop app skills folder
   # Location varies by OS:
   # macOS: ~/Library/Application Support/Claude/skills/
   # Windows: %APPDATA%/Claude/skills/
   # Linux: ~/.config/Claude/skills/
   ```

2. **Verify installation:**
   Open Claude and ask:
   ```
   "Analyze my ETH/USDC position with tick range 46080 to 50400, 
   current price $2,450, volatility 42%"
   ```

3. **You're ready!** UniClaw will provide comprehensive analysis with risk metrics.

---

## 📊 What Can UniClaw Do?

### Core Capabilities

| Feature | Description |
|---------|-------------|
| **Pool Creation** | Initialize pools with correct pricing and tick spacing |
| **Fee Accounting** | Complete `feeGrowthInside` formula implementation |
| **IL Calculation** | Precise impermanent loss tracking vs HODL strategy |
| **Position Health** | Distance to boundaries, efficiency, in-range status |
| **Risk Analytics** | VaR, volatility forecasting, Monte Carlo simulation |
| **Optimal Ranges** | Calculate ranges based on volatility and capital efficiency |
| **Backtesting** | Simulate strategies on historical data |
| **V4 Hooks** | Generate production-ready Solidity hooks |
| **Calldata Gen** | Exact transaction calldata for mint/burn/collect |

### Risk Assessment Framework

UniClaw provides **institutional-grade risk analytics**:

```
🎯 Volatility Analysis
  ├─ Realized Volatility (historical)
  ├─ EWMA Volatility (recent-weighted)
  ├─ GARCH(1,1) Forecasting
  └─ Parkinson Estimator

📊 Boundary Risk
  ├─ Probability of Exit (7d, 30d)
  ├─ Expected Time to Boundary
  ├─ Distance in Standard Deviations
  └─ Range Health Score (0-100)

💰 Value at Risk (VaR)
  ├─ Parametric VaR (95%, 99%)
  ├─ Historical VaR
  ├─ Conditional VaR (CVaR)
  └─ IL-Adjusted VaR

🎲 Monte Carlo Simulation
  ├─ 10,000 price path simulations
  ├─ Stay-in-range probability
  ├─ Expected fee capture
  └─ Scenario analysis

📈 Performance Metrics
  ├─ Sharpe Ratio
  ├─ Maximum Drawdown
  ├─ Capital Efficiency
  └─ Win Rate
```

---

## 💡 Example Usage

### Basic Position Analysis

```
"Analyze my position:
- Pool: ETH/USDC 0.3%
- Range: $2,200 - $2,700
- Current price: $2,450
- Entry price: $2,300
- Liquidity: 123456789012345
- Volatility: 42% annual"
```

**UniClaw Response:**
```
═══════════════════════════════════════
POSITION ANALYSIS: ETH/USDC 0.3%
═══════════════════════════════════════

💰 Fees & P&L
├─ Unclaimed Fees: $287.47
├─ Impermanent Loss: -$3.71 (-0.60%)
└─ Net Profit: $283.76

⚠️ Risk Assessment
├─ Overall Score: 58/100 🟡 MODERATE
├─ Exit Probability (7d): 28.5%
├─ VaR (1d, 95%): $243 (2.4%)
└─ Expected Time to Boundary: 7.6 days

📊 Recommendation
HOLD with active monitoring. Set alerts at 
$2,600 and $2,250. Review in 48 hours.
```

### Calculate Optimal Range

```
"Calculate optimal range for ETH/USDC with:
- Current price: $2,450
- Historical volatility: 35% annual
- Target capital efficiency: 80%
- I have 10 ETH and $24,500 USDC"
```

### Backtest Strategy

```
"Backtest a narrow-range strategy (±5%) vs wide-range 
strategy (±15%) on ETH/USDC using the last 90 days of 
price data. Compare ROI, Sharpe ratio, and drawdown."
```

### Generate V4 Hook

```
"Create a Uniswap V4 hook for dynamic fees based on 
volatility. High vol (>40%) → 1% fee, medium vol 
(20-40%) → 0.3% fee, low vol (<20%) → 0.05% fee."
```

---

## 🎯 Use Cases

### For Individual LPs
- Optimize range selection for maximum fee capture
- Calculate when to rebalance (gas cost vs benefit)
- Track true ROI (fees - IL - gas)
- Get alerts when position health deteriorates

### For LP Managers
- Backtest different strategies before deploying capital
- Compare narrow vs wide ranges with real data
- Generate risk reports for stakeholders
- Automate position monitoring

### For Developers
- Generate production-ready V4 hooks
- Get exact calldata for transactions
- Understand tick math and liquidity formulas
- Build custom LP strategies

### For Researchers
- Study IL dynamics across volatility regimes
- Analyze fee APR vs capital efficiency tradeoffs
- Model optimal range width using quantitative methods
- Simulate market scenarios with Monte Carlo

---

## 📚 Documentation

### Core Concepts

1. **[Tick Mathematics](./docs/tick-math.md)** - Price ↔ Tick conversions, liquidity calculations
2. **[Fee Accounting](./docs/fee-accounting.md)** - Complete feeGrowthInside formula
3. **[Risk Framework](./docs/risk-framework.md)** - VaR, volatility, Monte Carlo
4. **[V4 Hooks Guide](./docs/v4-hooks.md)** - Singleton, flash accounting, dynamic fees
5. **[Backtesting](./docs/backtesting.md)** - Strategy simulation and optimization

### Example Outputs

- [Position Analysis Example](./examples/position-analysis.md)
- [Risk Assessment Example](./examples/risk-assessment.md)
- [Optimal Range Calculation](./examples/optimal-range.md)
- [Backtest Results](./examples/backtest-comparison.md)

---

## 🧪 Evaluation Suite

UniClaw includes 5 comprehensive eval cases:

1. **Optimal Range Calculation** - Volatility-based range sizing
2. **Position Analysis** - Complete health check with risk metrics
3. **Transaction Generation** - Exact calldata for collect/compound
4. **Limit Orders** - Range orders using concentrated liquidity
5. **Strategy Comparison** - Backtest competing approaches

Run evals to verify skill performance:
```bash
# Using skill-creator (if you have it)
python eval_runner.py --skill uniclaw --eval all
```

---

## 🛠️ Technical Stack

**Built on proven DeFi knowledge:**
- [Uniswap V3 Whitepaper](https://uniswap.org/whitepaper-v3.pdf)
- [Uniswap V4 Whitepaper](https://uniswap.org/whitepaper-v4.pdf)
- [RareSkills Uniswap Tutorials](https://rareskills.io/blog/uniswap-v3)
- [Hummingbot Quants Lab](https://github.com/hummingbot/quants-lab)
- Official Uniswap Documentation

**Quantitative Methods:**
- Black-Scholes framework for probability calculations
- GARCH volatility modeling
- Monte Carlo simulation (Geometric Brownian Motion)
- VaR/CVaR risk metrics
- Modern Portfolio Theory (Sharpe ratios)

---

## 🤝 Contributing

We welcome contributions! See [CONTRIBUTING.md](./CONTRIBUTING.md) for guidelines.

**Ways to contribute:**
- 🐛 Report bugs or edge cases
- 📊 Add new risk metrics or strategies
- 📚 Improve documentation and examples
- 🧪 Create additional eval cases
- ⚡ Optimize calculations for gas efficiency
- 🎨 Build visualization tools

**Skill Development:**
```bash
# Clone repo
git clone https://github.com/your-org/uniclaw-skill.git
cd uniclaw-skill

# Edit SKILL.md
# Test with Claude

# Run evals
python test_skill.py

# Submit PR!
```

---

## 📜 License

MIT License - see [LICENSE](./LICENSE) for details.

**You are free to:**
- ✅ Use commercially
- ✅ Modify and distribute
- ✅ Use privately
- ✅ Sublicense

**Conditions:**
- Include original license and copyright
- Provide attribution to Orki Finance

---

## 🙏 Acknowledgments

Built with knowledge from:
- **Uniswap Labs** - Protocol design and documentation
- **RareSkills** - Deep technical tutorials on V3 mechanics
- **Hummingbot** - Quantitative research framework
- **Anthropic** - Claude AI platform and skill framework
- **DeFi Community** - Continuous feedback and improvements

Special thanks to all contributors and early testers!

---

## 📬 Contact & Support

- **Issues:** [GitHub Issues](https://github.com/your-org/uniclaw-skill/issues)
- **Discussions:** [GitHub Discussions](https://github.com/your-org/uniclaw-skill/discussions)
- **Twitter:** [@OrkiFinance](https://twitter.com/orkifinance) (if you have one)
- **Discord:** [Join our community](https://discord.gg/your-invite) (if you have one)

---

## ⭐ Star History

If UniClaw helps you manage LP positions more effectively, please give us a star! ⭐

It helps others discover the skill and motivates continued development.

---

## 🗺️ Roadmap

**V1.0 (Current)**
- ✅ Complete V3 position management
- ✅ Institutional risk analytics
- ✅ V4 hooks framework
- ✅ Backtesting engine

**V1.1 (Planned)**
- [ ] Real-time on-chain data integration
- [ ] Automated rebalancing strategies
- [ ] Multi-chain support (Arbitrum, Optimism, Base)
- [ ] Telegram/Discord alert bots

**V2.0 (Future)**
- [ ] Machine learning for volatility prediction
- [ ] Portfolio-level optimization (multiple positions)
- [ ] Integration with popular LP management tools
- [ ] Advanced MEV protection strategies

---

**Built with 🦞 by the DeFi community, for the DeFi community.**

*Making LP management quantitative, not emotional.*
